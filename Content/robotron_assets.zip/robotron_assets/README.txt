Health bar images from 
	https://kidscancode.org/godot_recipes/3d/healthbars/